using Stundenplan_V2;

public class StundenplanInput
{
    public List<UnterrichtsBlock> Blocks { get; set; } = new();
    public List<ZeitSlot> Slots { get; set; } = new();
    public Dictionary<string, int> Fachraeume { get; set; } = new();
    public Dictionary<string, int> ExtraFreieTage { get; set; } = new();
    public string ExcelPfad { get; set; }

    // Lehrer-Stammdaten (aus Sheet "Stammdaten")
    public Dictionary<string, LehrerStammdaten> LehrerStammdaten { get; set; } = new();

    // Parameter-Sheet
    public int ZeitlimitSekunden { get; set; } = 30;
    public int AnzahlLösungenOhneTausch { get; set; } = 2;
    public int AnzahlLösungenMitTausch { get; set; } = 2;
    public HashSet<string> NichtFreieTage { get; set; } = new HashSet<string>();

    // Qualitätsfunktion-Gewichte
    public int GewichtFrüheDoppel { get; set; } = 1;
    public int GewichtSpäteDoppel { get; set; } = 5;
    public int GewichtSpätePädEinheiten { get; set; } = 5;
    public int GewichtFreieTage { get; set; } = 2;

    // Hohlstunden-Strafen
    public int StrafeHohlstunde { get; set; } = 1;
    public int StrafeDoppelHohlstunde { get; set; } = 5;
    public int StrafeDreifachHohlstunde { get; set; } = 5;
    public int StrafeStdFolge { get; set; } = 5;
}

