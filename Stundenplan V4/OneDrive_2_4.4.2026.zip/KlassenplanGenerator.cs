﻿using ClosedXML.Excel;
using System.Collections.Generic;
using System.Linq;

namespace Stundenplan_V2
{
    public static class KlassenplanGenerator
    {
        public static void Erzeuge(
            string excelPfad,
            List<UnterrichtsBlock> unterrichtListe,
            List<ZeitSlot> zeitRaster,
            string suffix)
        {
            using var workbook = new XLWorkbook(excelPfad);

            string sheetName = "Klassenpläne_" + suffix;

            if (workbook.Worksheets.Any(ws => ws.Name == sheetName))
                workbook.Worksheet(sheetName).Delete();

            var sheet = workbook.Worksheets.Add(sheetName);

            sheet.Column(1).Width = 12;
            for (int i = 2; i <= 6; i++)
                sheet.Column(i).Width = 20;

            var tage = zeitRaster.Select(z => z.WTag).Distinct().ToList();
            var stunden = zeitRaster.Select(z => z.Stunde).Distinct().OrderBy(x => x).ToList();

            var alleKlassen = unterrichtListe
                .SelectMany(b => b.Teile)
                .SelectMany(t => t.Klassen)
                .Distinct()
                .OrderBy(x => x)
                .ToList();

            var blockLookup = unterrichtListe.ToDictionary(b => b.UNr);

            string Key(string lehrer, string fach, IEnumerable<string> klassen) =>
                lehrer + "|" + fach + "|" + string.Join(",", klassen.OrderBy(x => x));

            var spaeteDoppel = new HashSet<string>();

            for (int i = 0; i < zeitRaster.Count - 1; i++)
            {
                var s1 = zeitRaster[i];
                var s2 = zeitRaster[i + 1];

                if (s1.WTag != s2.WTag) continue;
                if (s1.Stunde + 1 != s2.Stunde) continue;

                foreach (var u1 in s1.BelegteUNrn)
                {
                    var b1 = blockLookup[u1];

                    foreach (var t1 in b1.Teile)
                    {
                        foreach (var u2 in s2.BelegteUNrn)
                        {
                            var b2 = blockLookup[u2];

                            foreach (var t2 in b2.Teile)
                            {
                                if (t1.Lehrer == t2.Lehrer &&
                                    t1.Fach == t2.Fach &&
                                    t1.Klassen.OrderBy(x => x)
                                      .SequenceEqual(t2.Klassen.OrderBy(x => x)))
                                {
                                    if (s1.Stunde >= 5)
                                        spaeteDoppel.Add(Key(t1.Lehrer, t1.Fach, t1.Klassen));
                                }
                            }
                        }
                    }
                }
            }

            int startRow = 1;

            foreach (var klasse in alleKlassen)
            {
                int planStart = startRow;

                sheet.Cell(startRow++, 1).Value = klasse;
                sheet.Cell(startRow - 1, 1).Style.Font.Bold = true;

                sheet.Cell(startRow, 1).Value = "Stunde";
                sheet.Cell(startRow, 1).Style.Font.Bold = true;

                for (int t = 0; t < tage.Count; t++)
                {
                    var c = sheet.Cell(startRow, t + 2);
                    c.Value = tage[t];
                    c.Style.Font.Bold = true;
                    c.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                }

                startRow++;

                foreach (var stunde in stunden)
                {
                    sheet.Row(startRow).Height = 45;
                    sheet.Cell(startRow, 1).Value = stunde;

                    for (int t = 0; t < tage.Count; t++)
                    {
                        string tag = tage[t];

                        var slot = zeitRaster
                            .FirstOrDefault(z => z.WTag == tag && z.Stunde == stunde);

                        if (slot == null) continue;

                        var cell = sheet.Cell(startRow, t + 2);

                        foreach (var u in slot.BelegteUNrn)
                        {
                            var block = blockLookup[u];

                            foreach (var teil in block.Teile)
                            {
                                if (!teil.Klassen.Contains(klasse))
                                    continue;

                                string key = Key(teil.Lehrer, teil.Fach, teil.Klassen);

                                cell.Clear();

                                var rt = cell.GetRichText();

                                rt.AddText(teil.Lehrer + "\n");
                                rt.AddText(teil.Fach + "\n");
                                rt.AddText($"UNr {block.UNr}    ");

                                var zt = rt.AddText(block.Zeilentext ?? "");
                                zt.Bold = true;
                                zt.FontSize = 13;

                                cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;
                                cell.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                                cell.Style.Alignment.WrapText = true;

                                bool istDoppel = false;

                                var next = zeitRaster
                                    .FirstOrDefault(z => z.WTag == tag && z.Stunde == stunde + 1);

                                if (next != null)
                                {
                                    foreach (var u2 in next.BelegteUNrn)
                                    {
                                        var b2 = blockLookup[u2];

                                        if (b2.Teile.Any(t2 =>
                                            t2.Lehrer == teil.Lehrer &&
                                            t2.Fach == teil.Fach &&
                                            t2.Klassen.OrderBy(x => x)
                                               .SequenceEqual(teil.Klassen.OrderBy(x => x))))
                                            istDoppel = true;
                                    }
                                }

                                var prev = zeitRaster
                                    .FirstOrDefault(z => z.WTag == tag && z.Stunde == stunde - 1);

                                if (prev != null)
                                {
                                    foreach (var u2 in prev.BelegteUNrn)
                                    {
                                        var b2 = blockLookup[u2];

                                        if (b2.Teile.Any(t2 =>
                                            t2.Lehrer == teil.Lehrer &&
                                            t2.Fach == teil.Fach &&
                                            t2.Klassen.OrderBy(x => x)
                                               .SequenceEqual(teil.Klassen.OrderBy(x => x))))
                                            istDoppel = true;
                                    }
                                }

                                bool spaeteEinzel =
                                    stunde >= 5 &&
                                    !istDoppel &&
                                    spaeteDoppel.Contains(key);

                                var fach = teil.Fach.Trim().ToUpper();

                                if (fach.EndsWith("L1"))
                                {
                                    cell.Style.Fill.BackgroundColor = XLColor.LightBlue;
                                }
                                else if (fach.EndsWith("L2"))
                                {
                                    cell.Style.Fill.BackgroundColor = XLColor.CornflowerBlue;
                                }
                                else if (istDoppel || spaeteEinzel)
                                {
                                    cell.Style.Fill.BackgroundColor = XLColor.Yellow;
                                }
                            }
                        }

                        if (slot.KlassenWunsch.ContainsKey(klasse))
                            FärbeZelle(cell, slot.KlassenWunsch[klasse]);

                        cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;
                        cell.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                        cell.Style.Alignment.WrapText = true;
                    }

                    startRow++;
                }

                var r = sheet.Range(planStart, 1, startRow - 1, tage.Count + 1);
                r.Style.Border.OutsideBorder = XLBorderStyleValues.Thick;
                r.Style.Border.InsideBorder = XLBorderStyleValues.Thin;

                startRow += 2;
            }

            workbook.Save();
        }

        private static void FärbeZelle(IXLCell cell, int wert)
        {
            switch (wert)
            {
                case -3:
                    cell.Style.Border.DiagonalBorder = XLBorderStyleValues.Thick;
                    cell.Style.Border.DiagonalUp = true;
                    cell.Style.Border.DiagonalDown = true;
                    break;

                case -2: cell.Style.Fill.BackgroundColor = XLColor.Red; break;
                case -1: cell.Style.Fill.BackgroundColor = XLColor.LightPink; break;
                case 1: cell.Style.Fill.BackgroundColor = XLColor.LightGreen; break;
                case 2: cell.Style.Fill.BackgroundColor = XLColor.Green; break;
                case 3: cell.Style.Fill.BackgroundColor = XLColor.DarkGreen; break;
            }
        }
    }
}