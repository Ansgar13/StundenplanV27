using ClosedXML.Excel;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace Stundenplan_V2
{
    public partial class MainWindow : Window
    {
        private string excelPfad = "";

        private StundenplanInput input;

        private readonly StundenplanService service =
            new StundenplanService(new OrToolsSolver());

        // label = "OhneTausch_1", "OhneTausch_2", "Tausch_5+7_1" usw.
        private List<(int quality, int badUnits, int[,] belegung, string label)> letzteSolutions = new();

        public MainWindow()
        {
            InitializeComponent();
        }

        // =====================================================
        // LOG
        // =====================================================
        public void Log(string text)
        {
            TxtLog.AppendText(text + Environment.NewLine);
            TxtLog.ScrollToEnd();
        }

        // =====================================================
        // BUTTON 1 – ZEITWÜNSCHE EINLESEN
        // =====================================================
        private void BtnZeitwuensche_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(excelPfad))
            {
                MessageBox.Show("Bitte zuerst Excel-Datei laden (Button 2).");
                return;
            }

            var dlgTxt = new OpenFileDialog();
            dlgTxt.Filter = "Textdateien (*.txt)|*.txt";
            dlgTxt.InitialDirectory = System.IO.Path.GetDirectoryName(excelPfad);

            if (dlgTxt.ShowDialog() != true)
                return;

            try
            {
                ZeitwunschExporter.ErzeugeZeitWL(excelPfad, dlgTxt.FileName);
                TxtStatus.Text = "ZeitWL und ZeitWK erzeugt.";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler:\n" + ex.Message);
            }
        }

        // =====================================================
        // BUTTON 2 – EXCEL EINLESEN
        // =====================================================
        private void BtnPfad_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog();
            dlg.Filter = "Excel Dateien (*.xlsx)|*.xlsx";

            if (dlg.ShowDialog() == true)
            {
                excelPfad = dlg.FileName;
                input = ExcelLoader.Lade(excelPfad);
                TxtStatus.Text = "Excel erfolgreich eingelesen.";
            }
        }

        // =====================================================
        // BUTTON 3 – STUNDENPLANERSTELLUNG
        // =====================================================
        private void BtnSchritt2_Click(object sender, RoutedEventArgs e)
        {
            if (input == null)
            {
                MessageBox.Show("Bitte zuerst Excel-Datei laden.");
                return;
            }

            Log("Starte Solver...");

            var solutions = service.Generate(input, Log, out string debug);

            if (solutions.Count == 0)
            {
                MessageBox.Show(debug);
                TxtStatus.Text = "Planung fehlgeschlagen.";
                return;
            }

            letzteSolutions = solutions.ToList();

            Log($"Lösungen gefunden: {letzteSolutions.Count}");
            foreach (var l in letzteSolutions)
                Log($"  [{l.label}] Qualität: {l.quality}, BadUnits: {l.badUnits}");

            // UNr-Plan hinzufügen
            var unrPlan = BewerteUnrPlan();
            letzteSolutions.Add(unrPlan);
            solutions.Add(unrPlan);

            SchreibeInExcel(solutions);
            SchreibeRanking(solutions);

            TxtStatus.Text = "Stundenverteilung abgeschlossen.";
        }

        // =====================================================
        // BUTTON 4 – LEHRERPLÄNE
        // =====================================================
        private void BtnLehrerplaene_Click(object sender, RoutedEventArgs e)
        {
            if (letzteSolutions.Count == 0)
            {
                MessageBox.Show("Bitte zuerst Stundenplan erstellen (Button 3).");
                return;
            }

            foreach (var sol in letzteSolutions)
            {
                SetzeLoesungInSlots(sol.belegung);
                LehrerplanGenerator.Erzeuge(excelPfad, input.Blocks, input.Slots, sol.label);
            }

            TxtStatus.Text = "Lehrerpläne für alle Lösungen erzeugt.";
        }

        // =====================================================
        // BUTTON 5 – KLASSENPLÄNE
        // =====================================================
        private void BtnKlassenplaene_Click(object sender, RoutedEventArgs e)
        {
            if (letzteSolutions.Count == 0)
            {
                MessageBox.Show("Bitte zuerst Stundenplan erstellen (Button 3).");
                return;
            }

            foreach (var sol in letzteSolutions)
            {
                SetzeLoesungInSlots(sol.belegung);
                KlassenplanGenerator.Erzeuge(excelPfad, input.Blocks, input.Slots, sol.label);
            }

            TxtStatus.Text = "Klassenpläne für alle Lösungen erzeugt.";
        }

        // =====================================================
        // BUTTON 6 – UNR-PLAN
        // =====================================================
        private void BtnUnrPlan_Click(object sender, RoutedEventArgs e)
        {
            if (letzteSolutions.Count == 0)
            {
                MessageBox.Show("Bitte zuerst Stundenplan erstellen.");
                return;
            }

            try
            {
                UnrPlanExporter.Erzeuge(
                    excelPfad,
                    input.Blocks,
                    input.Slots,
                    letzteSolutions[0].belegung
                );

                TxtStatus.Text = "UNr-Plan erzeugt.";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // =====================================================
        // TOP-PLÄNE IN TABELLE 2 SCHREIBEN
        // =====================================================
        private void SchreibeInExcel(
            List<(int quality, int badUnits, int[,] belegung, string label)> solutions)
        {
            using var workbook = new XLWorkbook(excelPfad);
            var sheet = workbook.Worksheet("Lösungen");

            sheet.Cell(1, 1).Value = "WTag";
            sheet.Cell(1, 2).Value = "Stunde";

            for (int p = 0; p < Math.Min(10, solutions.Count); p++)
                sheet.Cell(1, 3 + p).Value = solutions[p].label;

            for (int s = 0; s < input.Slots.Count; s++)
            {
                sheet.Cell(s + 2, 1).Value = input.Slots[s].WTag;
                sheet.Cell(s + 2, 2).Value = input.Slots[s].Stunde;

                for (int p = 0; p < Math.Min(10, solutions.Count); p++)
                {
                    var belegung = solutions[p].belegung;
                    var unrList = new List<int>();

                    for (int b = 0; b < input.Blocks.Count; b++)
                        if (belegung[b, s] == 1)
                            unrList.Add(input.Blocks[b].UNr);

                    sheet.Cell(s + 2, 3 + p).Value = string.Join(", ", unrList);
                }
            }

            int qualRow = input.Slots.Count + 3;
            sheet.Cell(qualRow, 1).Value = "Qualität";

            for (int p = 0; p < solutions.Count; p++)
                sheet.Cell(qualRow, 3 + p).Value = solutions[p].quality;

            workbook.Save();
        }

        private void SchreibeRanking(
            List<(int quality, int badUnits, int[,] belegung, string label)> solutions)
        {
            using var workbook = new XLWorkbook(excelPfad);

            if (workbook.Worksheets.Any(ws => ws.Name == "SolverRanking"))
                workbook.Worksheet("SolverRanking").Delete();

            var sheet = workbook.Worksheets.Add("SolverRanking");

            sheet.Cell(1, 1).Value = "Plan";
            sheet.Cell(1, 2).Value = "Label";
            sheet.Cell(1, 3).Value = "Qualität";
            sheet.Cell(1, 4).Value = "frühe Doppel";
            sheet.Cell(1, 5).Value = "späte Doppel";
            sheet.Cell(1, 6).Value = "pädagogische Einheiten spät";
            sheet.Cell(1, 7).Value = "Details späte pädagogische Einheiten";
            sheet.Row(1).Style.Font.Bold = true;

            for (int p = 0; p < solutions.Count; p++)
            {
                var bewertung = PlanBewertung.Berechne(
                    solutions[p].belegung,
                    input.Blocks,
                    input.Slots);

                sheet.Cell(p + 2, 1).Value = p + 1;
                sheet.Cell(p + 2, 2).Value = solutions[p].label;
                sheet.Cell(p + 2, 3).Value = bewertung.Quality;
                sheet.Cell(p + 2, 4).Value = bewertung.Early;
                sheet.Cell(p + 2, 5).Value = bewertung.Late;
                sheet.Cell(p + 2, 6).Value = bewertung.BadUnits;
                sheet.Cell(p + 2, 7).Value = string.Join("\n", bewertung.Details);
                sheet.Cell(p + 2, 7).Style.Alignment.WrapText = true;
            }

            sheet.Columns().AdjustToContents();
            workbook.Save();
        }

        // =====================================================
        // UNR-PLAN AUS EXCEL LADEN
        // =====================================================
        private int[,] LadeUnrPlanAusExcel()
        {
            int B = input.Blocks.Count;
            int S = input.Slots.Count;
            int[,] belegung = new int[B, S];

            using var wb = new XLWorkbook(excelPfad);
            var sheet = wb.Worksheet("Unr-Plan");

            for (int s = 0; s < S; s++)
            {
                int col = 3;
                while (true)
                {
                    var cell = sheet.Cell(s + 2, col);
                    if (cell.IsEmpty()) break;

                    int unr = cell.GetValue<int>();
                    for (int b = 0; b < input.Blocks.Count; b++)
                        if (input.Blocks[b].UNr == unr)
                            belegung[b, s] = 1;

                    col++;
                }
            }

            return belegung;
        }

        private (int quality, int badUnits, int[,] belegung, string label) BewerteUnrPlan()
        {
            int[,] belegung = LadeUnrPlanAusExcel();

            var b = PlanBewertung.Berechne(belegung, input.Blocks, input.Slots);

            return (b.Quality, b.BadUnits, belegung, "UNrPlan");
        }

        // =====================================================
        // LÖSUNG IN ZEITSLOTS SCHREIBEN
        // =====================================================
        private void SetzeLoesungInSlots(int[,] belegung)
        {
            foreach (var slot in input.Slots)
                slot.BelegteUNrn.Clear();

            for (int b = 0; b < input.Blocks.Count; b++)
                for (int s = 0; s < input.Slots.Count; s++)
                    if (belegung[b, s] == 1)
                        input.Slots[s].BelegteUNrn.Add(input.Blocks[b].UNr);
        }
    }
}
