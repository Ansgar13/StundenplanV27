using Google.OrTools.Sat;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Stundenplan_V2
{
    public static class StundenplanEngine
    {
        // =====================================================
        // TAUSCHGRUPPE
        // Zahl  = Gruppen-ID  (z.B. "5" aus "5a" und "5b")
        // BuchstabeA / BuchstabeB = die beiden Lehrer-Rollen
        // BlocksA / BlocksB = Block-Indizes je Rolle
        // LehrerA / LehrerB = tatsächliche Lehrernamen
        // =====================================================
        class TauschGruppe
        {
            public string Zahl;
            public string BuchstabeA;
            public string BuchstabeB;
            public List<int> BlocksA = new(); // Block-Indizes für Buchstabe A
            public List<int> BlocksB = new(); // Block-Indizes für Buchstabe B
            public string LehrerA;            // Lehrername zu Buchstabe A
            public string LehrerB;            // Lehrername zu Buchstabe B
        }

        // =====================================================
        // ÖFFENTLICHE EINSTIEGSMETHODE
        // Gibt zurück: 2 beste ohne Tausch + 2 beste mit Tausch
        // =====================================================
        public static List<(int quality, int badUnits, int[,] belegung, string label)> Planen(
            string excelPfad,
            List<UnterrichtsBlock> blocks,
            List<ZeitSlot> slots,
            Dictionary<string, int> fachraumLimit,
            Dictionary<string, int> extraFreieTage,
            Action<string> log,
            out string debug)
        {
            // --------------------------------------------------
            // Tauschgruppen aufbauen
            // --------------------------------------------------
            var tauschGruppen = BaueTauschGruppen(blocks);

            log($"Tauschgruppen gefunden: {tauschGruppen.Count}");
            foreach (var g in tauschGruppen)
                log($"  Gruppe {g.Zahl}: {g.BuchstabeA}({g.LehrerA}, {g.BlocksA.Count} Blöcke) <-> {g.BuchstabeB}({g.LehrerB}, {g.BlocksB.Count} Blöcke)");

            // --------------------------------------------------
            // PHASE 1: Ohne Tausch – 2 beste Lösungen
            // --------------------------------------------------
            log("Phase 1: Ohne Tausch...");
            var ohneBlöcke = blocks; // Original-Blöcke
            var ohneLösungen = PlanenIntern(
                excelPfad, blocks, slots, fachraumLimit, extraFreieTage,
                log, maxLösungen: 2, tauschInfo: null);

            log($"  Ohne Tausch: {ohneLösungen.Count} Lösungen, beste Qualität: {(ohneLösungen.Count > 0 ? ohneLösungen[0].quality.ToString() : "–")}");

            // --------------------------------------------------
            // PHASE 2: 5 zufällige Tausch-Kombinationen
            // --------------------------------------------------
            var mitTauschLösungen = new List<(int quality, int badUnits, int[,] belegung, string tauschLabel)>();

            if (tauschGruppen.Count > 0)
            {
                var rng = new Random(42);
                var verwendeteTausche = new HashSet<string>();

                for (int versuch = 0; versuch < 5; versuch++)
                {
                    // Zufällige Teilmenge der Tauschgruppen auswählen (mindestens 1)
                    var ausgewählt = WähleZufälligenErlaubtenTausch(tauschGruppen, rng);

                    string tauschKey = string.Join("+", ausgewählt.Select(g => g.Zahl).OrderBy(z => z));

                    if (verwendeteTausche.Contains(tauschKey))
                    {
                        log($"  Tausch-Kombination {tauschKey} bereits versucht, überspringe.");
                        continue;
                    }

                    verwendeteTausche.Add(tauschKey);

                    log($"Phase 2 Versuch {versuch + 1}: Tausche Gruppen [{tauschKey}]...");

                    // Blöcke mit angewandtem Tausch klonen
                    var getauschteBlöcke = WendeTauschAn(blocks, ausgewählt);

                    var lösungen = PlanenIntern(
                        excelPfad, getauschteBlöcke, slots, fachraumLimit, extraFreieTage,
                        log, maxLösungen: 2, tauschInfo: ausgewählt);

                    foreach (var l in lösungen)
                        mitTauschLösungen.Add((l.quality, l.badUnits, l.belegung, $"Tausch_{tauschKey}"));

                    log($"  Qualitäten: {string.Join(", ", lösungen.Select(l => l.quality))}");
                }
            }
            else
            {
                log("Keine Tauschgruppen vorhanden – überspringe Phase 2.");
            }

            // --------------------------------------------------
            // Ergebnisse zusammenstellen
            // --------------------------------------------------
            var ergebnis = new List<(int quality, int badUnits, int[,] belegung, string label)>();

            // 2 beste ohne Tausch
            foreach (var l in ohneLösungen.Take(2))
                ergebnis.Add((l.quality, l.badUnits, l.belegung, l.label));

            // 2 beste mit Tausch
            var top2MitTausch = mitTauschLösungen
                .OrderByDescending(l => l.quality)
                .Take(2)
                .ToList();

            foreach (var l in top2MitTausch)
                ergebnis.Add((l.quality, l.badUnits, l.belegung, l.tauschLabel));

            // Tauschliste exportieren (beste mit-Tausch-Lösung)
            if (top2MitTausch.Count > 0)
            {
                var besteTauschGruppen = BaueTauschGruppen(blocks); // original für Export
                ExportiereTauschListe(excelPfad, blocks, besteTauschGruppen);
            }

            debug = $"{ohneLösungen.Count} Lösungen ohne Tausch, {top2MitTausch.Count} beste mit Tausch.";
            return ergebnis;
        }

        // =====================================================
        // INTERNER SOLVER
        // tauschInfo = null → kein Tausch; sonst: welche Gruppen getauscht
        // =====================================================
        private static List<(int quality, int badUnits, int[,] belegung, string label)> PlanenIntern(
            string excelPfad,
            List<UnterrichtsBlock> blocks,
            List<ZeitSlot> slots,
            Dictionary<string, int> fachraumLimit,
            Dictionary<string, int> extraFreieTage,
            Action<string> log,
            int maxLösungen,
            List<TauschGruppe> tauschInfo)
        {
            var model = new CpModel();
            int B = blocks.Count;
            int S = slots.Count;

            // =====================================================
            // FREIE TAGE
            // =====================================================
            var lehrerListe = blocks
                .SelectMany(b => b.Teile)
                .Select(t => t.Lehrer)
                .Distinct()
                .ToList();

            var tageListe = slots
                .Select(s => s.WTag)
                .Distinct()
                .ToList();

            BoolVar[,] free = new BoolVar[lehrerListe.Count, tageListe.Count];

            for (int l = 0; l < lehrerListe.Count; l++)
                for (int day = 0; day < tageListe.Count; day++)
                    free[l, day] = model.NewBoolVar($"free_{l}_{day}");

            for (int l = 0; l < lehrerListe.Count; l++)
            {
                string name = lehrerListe[l];
                if (!extraFreieTage.ContainsKey(name)) continue;

                model.Add(LinearExpr.Sum(
                    Enumerable.Range(0, tageListe.Count).Select(day => free[l, day])
                ) == extraFreieTage[name]);
            }

            for (int l = 0; l < lehrerListe.Count; l++)
            {
                string lehrer = lehrerListe[l];
                for (int day = 0; day < tageListe.Count; day++)
                {
                    string tag = tageListe[day];
                    bool istFixFrei = slots
                        .Where(s => s.WTag == tag)
                        .All(s => s.LehrerWunsch.TryGetValue(lehrer, out int lw) && lw == -3);

                    if (istFixFrei)
                        model.Add(free[l, day] == 0);
                }
            }

            // =====================================================
            // ENTSCHEIDUNGSVARIABLEN
            // =====================================================
            BoolVar[,] x = new BoolVar[B, S];
            for (int b = 0; b < B; b++)
                for (int s = 0; s < S; s++)
                    x[b, s] = model.NewBoolVar($"x_b{b}_s{s}");

            // =====================================================
            // WOCHENSTUNDEN
            // =====================================================
            for (int b = 0; b < B; b++)
                model.Add(LinearExpr.Sum(Enumerable.Range(0, S).Select(s => x[b, s])) == blocks[b].Wst);

            // =====================================================
            // FIX-UNR
            // =====================================================
            for (int s = 0; s < S; s++)
                foreach (var unr in slots[s].FixUNrn)
                    for (int b = 0; b < B; b++)
                        if (blocks[b].UNr == unr)
                            model.Add(x[b, s] == 1);

            // =====================================================
            // LEHRERREGEL
            // =====================================================
            for (int s = 0; s < S; s++)
            {
                var map = new Dictionary<string, List<int>>();
                for (int b = 0; b < B; b++)
                    foreach (var l in blocks[b].Teile.Select(t => t.Lehrer).Distinct())
                    {
                        if (!map.ContainsKey(l)) map[l] = new List<int>();
                        map[l].Add(b);
                    }

                foreach (var kv in map)
                    model.Add(LinearExpr.Sum(kv.Value.Select(b => x[b, s])) <= 1);
            }

            // =====================================================
            // KLASSENREGEL
            // =====================================================
            ClassConstraint.Add(model, x, blocks, S);

            // =====================================================
            // FACHRAUMLIMIT
            // =====================================================
            RoomConstraint.Add(model, x, blocks, fachraumLimit, S);

            // =====================================================
            // SPERRSLOTS (-3)
            // =====================================================
            TimeConstraint.AddBlockedSlots(model, x, blocks, slots, B, S);

            // =====================================================
            // FREIE TAGE CONSTRAINT
            // =====================================================
            FreeDayConstraint.Add(model, x, free, blocks, slots, lehrerListe, tageListe, B);

            // =====================================================
            // DOPPELSTUNDENVARIABLEN
            // =====================================================
            BoolVar[,] d = new BoolVar[B, S];

            for (int b = 0; b < B; b++)
            {
                for (int s = 0; s < S - 1; s++)
                {
                    if (slots[s].WTag == slots[s + 1].WTag &&
                        slots[s].Stunde + 1 == slots[s + 1].Stunde)
                    {
                        d[b, s] = model.NewBoolVar($"d_b{b}_s{s}");
                        model.Add(x[b, s] == 1).OnlyEnforceIf(d[b, s]);
                        model.Add(x[b, s + 1] == 1).OnlyEnforceIf(d[b, s]);
                        model.Add(x[b, s] + x[b, s + 1] - d[b, s] <= 1);
                    }
                }
            }

            // =====================================================
            // WOCHEN-DOPPELSTUNDENLIMITS
            // =====================================================
            for (int b = 0; b < B; b++)
            {
                int minD = blocks[b].Teile.Max(t => t.MinDoppel);
                int maxD = blocks[b].Teile.Max(t => t.MaxDoppel);

                var dVars = new List<BoolVar>();
                for (int s = 0; s < S - 1; s++)
                    if (d[b, s] != null) dVars.Add(d[b, s]);

                if (dVars.Count > 0)
                {
                    model.Add(LinearExpr.Sum(dVars) >= minD);
                    model.Add(LinearExpr.Sum(dVars) <= maxD);
                }
            }

            // =====================================================
            // KEINE 3 STUNDEN HINTEREINANDER
            // =====================================================
            for (int b = 0; b < B; b++)
                for (int s = 0; s < S - 2; s++)
                    if (slots[s].WTag == slots[s + 1].WTag &&
                        slots[s].WTag == slots[s + 2].WTag &&
                        slots[s].Stunde + 1 == slots[s + 1].Stunde &&
                        slots[s].Stunde + 2 == slots[s + 2].Stunde)
                        model.Add(x[b, s] + x[b, s + 1] + x[b, s + 2] <= 2);

            // =====================================================
            // SPÄTE PÄDAGOGISCHE EINHEITEN
            // =====================================================
            var badEinheiten = PlanBewertung.SolverSpaetePaedEinheiten(model, x, blocks, slots);

            // =====================================================
            // TAGESREGEL (max 2 Stunden pro Block pro Tag)
            // =====================================================
            var tage = slots.Select(z => z.WTag).Distinct();

            foreach (var tag in tage)
            {
                var daySlots = slots
                    .Select((z, i) => new { z, i })
                    .Where(z => z.z.WTag == tag)
                    .OrderBy(z => z.z.Stunde)
                    .ToList();

                for (int b = 0; b < B; b++)
                    model.Add(LinearExpr.Sum(daySlots.Select(z => x[b, z.i])) <= 2);
            }

            // =====================================================
            // FACH PRO KLASSE PRO TAG MAX 2
            // =====================================================
            var fachKlasseMap = new Dictionary<(string klasse, string fach), List<int>>();

            for (int b = 0; b < B; b++)
                foreach (var t in blocks[b].Teile)
                    foreach (var k in t.Klassen)
                    {
                        var key = (k, t.Fach);
                        if (!fachKlasseMap.ContainsKey(key)) fachKlasseMap[key] = new List<int>();
                        fachKlasseMap[key].Add(b);
                    }

            foreach (var tag in tage)
            {
                var daySlots = slots
                    .Select((z, i) => new { z, i })
                    .Where(z => z.z.WTag == tag)
                    .Select(z => z.i)
                    .ToList();

                foreach (var kv in fachKlasseMap)
                {
                    var vars = new List<IntVar>();
                    foreach (var b in kv.Value)
                        foreach (var s in daySlots)
                            vars.Add(x[b, s]);

                    model.Add(LinearExpr.Sum(vars) <= 2);
                }
            }

            // =====================================================
            // ZIELFUNKTION
            // =====================================================
            var earlyVars = new List<BoolVar>();
            var lateVars = new List<BoolVar>();

            for (int b = 0; b < B; b++)
                for (int s = 0; s < S - 1; s++)
                {
                    if (d[b, s] == null) continue;
                    if (slots[s].Stunde <= 5) earlyVars.Add(d[b, s]);
                    else lateVars.Add(d[b, s]);
                }

            var freeRewardVars = new List<BoolVar>();
            for (int l = 0; l < lehrerListe.Count; l++)
                for (int day = 0; day < tageListe.Count; day++)
                    if (tageListe[day] != "Fr")
                        freeRewardVars.Add(free[l, day]);

            var qualityExpr = ObjectiveBuilder.Build(model, earlyVars, lateVars, badEinheiten, freeRewardVars);
            model.Maximize(qualityExpr);

            // =====================================================
            // SOLVER
            // =====================================================
            var solver = new CpSolver();
            solver.StringParameters =
                "max_time_in_seconds:10 num_search_workers:8 random_seed:1 log_search_progress:true";

            var lösungen = new List<(int quality, int badUnits, int[,] belegung, string label)>();

            string labelPrefix = tauschInfo == null
                ? "OhneTausch"
                : "Tausch_" + string.Join("+", tauschInfo.Select(g => g.Zahl).OrderBy(z => z));

            // Phase 1: Beste Lösung
            var status = solver.Solve(model);

            if (status != CpSolverStatus.Optimal && status != CpSolverStatus.Feasible)
                return lösungen;

            int bestQuality = (int)solver.Value(qualityExpr);
            var bestBelegung = ExtrahiereBelegung(solver, x, B, S);
            int bestBad = badEinheiten.Count(v => solver.Value(v) == 1);

            lösungen.Add((bestQuality, bestBad, bestBelegung, labelPrefix + "_1"));

            // Phase 2: Weitere diverse Lösungen
            for (int k = 1; k < maxLösungen; k++)
            {
                model.Add(qualityExpr <= bestQuality);

                var forbid = new List<ILiteral>();
                for (int b = 0; b < B; b++)
                    for (int s = 0; s < S; s++)
                    {
                        if (bestBelegung[b, s] == 1) forbid.Add(x[b, s].Not());
                        else forbid.Add(x[b, s]);
                    }

                model.AddBoolOr(forbid);

                status = solver.Solve(model);

                if (status != CpSolverStatus.Optimal && status != CpSolverStatus.Feasible)
                    break;

                int quality = (int)solver.Value(qualityExpr);
                var belegung = ExtrahiereBelegung(solver, x, B, S);
                int badCount = badEinheiten.Count(v => solver.Value(v) == 1);

                lösungen.Add((quality, badCount, belegung, labelPrefix + "_" + (k + 1)));
                bestBelegung = belegung;
            }

            return lösungen;
        }

        // =====================================================
        // TAUSCHGRUPPEN AUFBAUEN
        // Zahl = Gruppen-ID, Buchstabe = Lehrer-Rolle
        // Pro Zahl darf es genau 2 Buchstaben geben.
        // =====================================================
        private static List<TauschGruppe> BaueTauschGruppen(List<UnterrichtsBlock> blocks)
        {
            // Sammle alle LTKZ: (Zahl, Buchstabe) -> (Lehrer, BlockIndex-Liste)
            var dict = new Dictionary<(string zahl, string buchstabe), (string lehrer, List<int> blockIds)>();

            for (int b = 0; b < blocks.Count; b++)
            {
                foreach (var t in blocks[b].Teile)
                {
                    if (string.IsNullOrWhiteSpace(t.Ltkz)) continue;

                    string ltkz = t.Ltkz.Trim();
                    string zahl = new string(ltkz.TakeWhile(char.IsDigit).ToArray());
                    string buchstabe = ltkz.Substring(zahl.Length).Trim().ToLower();

                    if (string.IsNullOrEmpty(zahl) || string.IsNullOrEmpty(buchstabe)) continue;

                    var key = (zahl, buchstabe);

                    if (!dict.ContainsKey(key))
                        dict[key] = (t.Lehrer, new List<int>());

                    dict[key].blockIds.Add(b);
                    // Lehrer überschreiben ist OK – sollte konsistent sein
                }
            }

            // Gruppiere nach Zahl, suche Paare mit genau 2 Buchstaben
            var result = new List<TauschGruppe>();

            var nachZahl = dict.GroupBy(kv => kv.Key.zahl);

            foreach (var gruppe in nachZahl)
            {
                var einträge = gruppe.ToList();
                if (einträge.Count != 2) continue; // nur Paare

                var eintragA = einträge[0];
                var eintragB = einträge[1];

                result.Add(new TauschGruppe
                {
                    Zahl = gruppe.Key,
                    BuchstabeA = eintragA.Key.buchstabe,
                    BuchstabeB = eintragB.Key.buchstabe,
                    BlocksA = eintragA.Value.blockIds,
                    BlocksB = eintragB.Value.blockIds,
                    LehrerA = eintragA.Value.lehrer,
                    LehrerB = eintragB.Value.lehrer,
                });
            }

            return result;
        }

        // =====================================================
        // ZUFÄLLIGEN ERLAUBTEN TAUSCH WÄHLEN
        // Wählt eine nicht-leere zufällige Teilmenge der Gruppen.
        // Alle gewählten Gruppen werden getauscht.
        // =====================================================
        private static List<TauschGruppe> WähleZufälligenErlaubtenTausch(
            List<TauschGruppe> gruppen,
            Random rng)
        {
            // Wähle zufällig 1 bis alle Gruppen
            int anzahl = rng.Next(1, gruppen.Count + 1);
            return gruppen.OrderBy(_ => rng.Next()).Take(anzahl).ToList();
        }

        // =====================================================
        // TAUSCH ANWENDEN: Lehrer in Blöcken tauschen
        // Gibt eine tiefe Kopie der Blocks zurück mit getauschten Lehrern
        // =====================================================
        private static List<UnterrichtsBlock> WendeTauschAn(
            List<UnterrichtsBlock> original,
            List<TauschGruppe> zuTauschen)
        {
            // Deep copy der Blöcke
            var kopie = original.Select(b => new UnterrichtsBlock
            {
                UNr = b.UNr,
                Wst = b.Wst,
                Zeilentext = b.Zeilentext,
                WochenDoppelstunden = b.WochenDoppelstunden,
                TagesDoppelstunden = new Dictionary<string, int>(b.TagesDoppelstunden),
                Teile = b.Teile.Select(t => new TeilUnterricht
                {
                    UNr = t.UNr,
                    Lehrer = t.Lehrer,
                    Fach = t.Fach,
                    Klassen = new List<string>(t.Klassen),
                    MinDoppel = t.MinDoppel,
                    MaxDoppel = t.MaxDoppel,
                    FachGruppe = t.FachGruppe,
                    AktuelleDoppelstunden = t.AktuelleDoppelstunden,
                    Ltkz = t.Ltkz
                }).ToList()
            }).ToList();

            // Für jede zu tauschende Gruppe: Lehrer A und B in allen Blöcken tauschen
            foreach (var g in zuTauschen)
            {
                // Alle Blöcke mit Buchstabe A → Lehrer wird zu LehrerB
                foreach (int idx in g.BlocksA)
                {
                    foreach (var t in kopie[idx].Teile)
                    {
                        if (t.Lehrer == g.LehrerA)
                            t.Lehrer = g.LehrerB;
                    }
                }

                // Alle Blöcke mit Buchstabe B → Lehrer wird zu LehrerA
                foreach (int idx in g.BlocksB)
                {
                    foreach (var t in kopie[idx].Teile)
                    {
                        if (t.Lehrer == g.LehrerB)
                            t.Lehrer = g.LehrerA;
                    }
                }
            }

            return kopie;
        }

        // =====================================================
        // HILFSMETHODE: Belegung aus Solver extrahieren
        // =====================================================
        private static int[,] ExtrahiereBelegung(CpSolver solver, BoolVar[,] x, int B, int S)
        {
            var belegung = new int[B, S];
            for (int b = 0; b < B; b++)
                for (int s = 0; s < S; s++)
                    belegung[b, s] = (int)solver.Value(x[b, s]);
            return belegung;
        }

        // =====================================================
        // TAUSCHLISTE EXPORTIEREN
        // =====================================================
        private static void ExportiereTauschListe(
            string excelPfad,
            List<UnterrichtsBlock> blocks,
            List<TauschGruppe> tauschGruppen)
        {
            using var wb = new ClosedXML.Excel.XLWorkbook(excelPfad);

            if (wb.Worksheets.Any(ws => ws.Name == "Tauschliste"))
                wb.Worksheet("Tauschliste").Delete();

            var sheet = wb.Worksheets.Add("Tauschliste");

            sheet.Cell(1, 1).Value = "Gruppen-Nr";
            sheet.Cell(1, 2).Value = "Buchstabe";
            sheet.Cell(1, 3).Value = "UNr";
            sheet.Cell(1, 4).Value = "Original Lehrer";
            sheet.Cell(1, 5).Value = "Tausch Lehrer";
            sheet.Row(1).Style.Font.Bold = true;

            int row = 2;

            foreach (var g in tauschGruppen)
            {
                foreach (int idx in g.BlocksA)
                {
                    sheet.Cell(row, 1).Value = g.Zahl;
                    sheet.Cell(row, 2).Value = g.BuchstabeA;
                    sheet.Cell(row, 3).Value = blocks[idx].UNr;
                    sheet.Cell(row, 4).Value = g.LehrerA;
                    sheet.Cell(row, 5).Value = g.LehrerB;
                    row++;
                }

                foreach (int idx in g.BlocksB)
                {
                    sheet.Cell(row, 1).Value = g.Zahl;
                    sheet.Cell(row, 2).Value = g.BuchstabeB;
                    sheet.Cell(row, 3).Value = blocks[idx].UNr;
                    sheet.Cell(row, 4).Value = g.LehrerB;
                    sheet.Cell(row, 5).Value = g.LehrerA;
                    row++;
                }
            }

            sheet.Columns().AdjustToContents();
            wb.Save();
        }

        // =====================================================
        // (wird nicht mehr intern gebraucht, kann gelöscht werden)
        // =====================================================
        private static bool IstGleichePaedagogischeEinheit(UnterrichtsBlock a, UnterrichtsBlock b)
        {
            foreach (var t1 in a.Teile)
                foreach (var t2 in b.Teile)
                    if (t1.Fach == t2.Fach && t1.Klassen.Intersect(t2.Klassen).Any())
                        return true;
            return false;
        }
    }
}
