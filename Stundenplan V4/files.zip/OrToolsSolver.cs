using Stundenplan_V2;

public interface ISolver
{
    List<(int quality, int badUnits, int[,] belegung, string label)> Solve(
        StundenplanInput input,
        Action<string> log,
        out string debug);
}

public class OrToolsSolver : ISolver
{
    public List<(int quality, int badUnits, int[,] belegung, string label)> Solve(
        StundenplanInput input,
        Action<string> log,
        out string debug)
    {
        return StundenplanEngine.Planen(
            input.ExcelPfad,
            input.Blocks,
            input.Slots,
            input.Fachraeume,
            input.ExtraFreieTage,
            log,
            out debug
        );
    }
}
